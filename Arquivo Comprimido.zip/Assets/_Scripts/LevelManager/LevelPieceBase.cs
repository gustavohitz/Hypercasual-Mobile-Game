using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelPieceBase : MonoBehaviour {

    public Transform endPiece;
  
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class SOFloat : ScriptableObject {

    public float value;
    
}
